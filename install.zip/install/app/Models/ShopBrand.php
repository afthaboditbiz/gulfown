<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopBrand extends Model
{
    protected $fillable = [
        'shop_id', 'brand_id'
    ];
}
